package com.example.tp_poo.models;

public class Anamnese {

}
