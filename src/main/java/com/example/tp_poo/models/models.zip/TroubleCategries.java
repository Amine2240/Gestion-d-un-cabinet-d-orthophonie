package com.example.tp_poo.models;

public enum TroubleCategries {
    DEGLUTITION,
    NEURO_DEVELOPPEMENTAUX,
    COGNITIFS
}
