package com.example.tp_poo.models;

public class Exception1 extends Exception{
    public Exception1(String message){
        super(message);
    }

}
