package com.example.tp_poo;

import com.calendarfx.view.CalendarView;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class LoginController {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    public TextField username;
    public PasswordField password;
    public Label errorLabel;
    public void switchToSignupScene(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("SignupScene.fxml")));
        stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

//    public void showCalendarScene(ActionEvent event) throws IOException {
//        // Create and show the calendar scene
//        if (username.getText().equals("admin") && password.getText().equals("admin")) {
//            Mycalendar calendarView = new Mycalendar();
//            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//            Scene calendarScene = new Scene(calendarView.getRoot(), 1300, 1000);
//
//            stage.setScene(calendarScene);
//            stage.show();
//        }
//        else {
//            errorLabel.setText("Invalid username or password");
//
//        }
//    }
public void allerVersHome(ActionEvent event) throws IOException {
    if (username.getText().equals("admin") && password.getText().equals("admin")) {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("HomeScene.fxml")));
        stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    else {
        errorLabel.setText("Invalid username or password");

    }


}
}
