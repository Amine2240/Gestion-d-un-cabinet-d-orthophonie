package com.example.tp_poo.models;

public class Objectif {
    private String nomObjectif;
    private CategoriesObjectif categorieObjectif;
    public Objectif(String nomObjectif, CategoriesObjectif categorieObjectif){
        this.nomObjectif = nomObjectif;
        this.categorieObjectif = categorieObjectif;
    }
}
