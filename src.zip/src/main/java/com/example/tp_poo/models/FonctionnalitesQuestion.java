package com.example.tp_poo.models;

public interface FonctionnalitesQuestion {
    public void ajouterQuestion(Question question);
    public void supprimerQuestion(Question question);
    public void modifierQuestion(Question question);
}
