package com.example.tp_poo.models;

public interface FonctionnalitesTrouble {
    public void afficherPatientsSouffrantDunTrouble(Trouble trouble);
    public double pourcentagePatientsParTrouble(Trouble trouble);
}
