package com.example.tp_poo.models;

public class Exception2 extends Exception{
    public Exception2(String message){
        super(message);
    }
}
