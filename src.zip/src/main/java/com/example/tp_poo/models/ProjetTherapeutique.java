package com.example.tp_poo.models;

public class ProjetTherapeutique {
    protected String textDemarcheTherapeutique;
    public ProjetTherapeutique(String textDemarcheTherapeutique){
        this.textDemarcheTherapeutique = textDemarcheTherapeutique;
    }
    public String getTextDemarcheTherapeutique(){
        return textDemarcheTherapeutique;
    }

}
