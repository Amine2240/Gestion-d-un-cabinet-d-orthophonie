package com.example.tp_poo.models;

public enum CategoriesObjectif {
    COURT_TERME,
    MOYEN_TERME,
    LONG_TERME
}
