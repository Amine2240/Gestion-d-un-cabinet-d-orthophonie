package com.example.tp_poo.models;

public class QuestionRpsLibres extends Question{
    private String reponsePatientLibre;

    public QuestionRpsLibres(String questionEnonce) {
        super(questionEnonce);
       // this.reponsePatientLibre = reponsePatientLibre;
    }
}
