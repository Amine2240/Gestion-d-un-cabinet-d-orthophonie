package com.example.tp_poo.models;

public interface FonctionnalitesAnamnese {
    public Anamnese creerAnamnese(Anamnese anamnese);
    public void sauvegarderAnamnese(Anamnese anamnese);
    public void modifierAnamnese(Anamnese anamnese);
}
