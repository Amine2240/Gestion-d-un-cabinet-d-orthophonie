package com.example.tp_poo.models;

public interface FonctionnalitesExercice {
    public void ajouterExercice(Exercice exercice);
    public void supprimerExercice(Exercice exercice);
    public void modifierExercice(Exercice exercice);
}
