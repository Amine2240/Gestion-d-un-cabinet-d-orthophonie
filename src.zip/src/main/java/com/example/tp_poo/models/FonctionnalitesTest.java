package com.example.tp_poo.models;

public interface FonctionnalitesTest {
    public Test creerTest(Test test);
    public void sauvegarderTest(Test test);
    public void modifierTest(Test test);
}
