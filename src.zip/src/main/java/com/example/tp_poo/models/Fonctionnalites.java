package com.example.tp_poo.models;

import java.util.ArrayList;

public interface Fonctionnalites {
//    public Test creerTest(Test test);
//    public void sauvegarderTest(Test test);
//    public void modifierTest(Test test);

//    public Anamnese creerAnamnese(Anamnese anamnese);
//    public void sauvegarderAnamnese(Anamnese anamnese);
//    public void modifierAnamnese(Anamnese anamnese);

//    public void ajouterQuestion(Question question);
//    public void supprimerQuestion(Question question);
//    public void modifierQuestion(Question question);

//    public void ajouterExercice(Exercice exercice);
//    public void supprimerExercice(Exercice exercice);
//    public void modifierExercice(Exercice exercice);

//    public void consulterDossierPatient(DossierPatient dossierPatient);
//    public void consulterObservation(RendezVous rendezVous);
//    public void consulterCompteRenduTests(EpreuveClinique epreuveClinique);//orthogonisteObservation
//    public void consulterBOsDossierPatient(DossierPatient dossierPatient);
//    public void consulterFichesSuiviDossierPatient(DossierPatient dossierPatient);
//    public void afficherCourbe(FicheSuivi ficheSuivi);


//    public void afficherPatientsSouffrantDunTrouble(Trouble trouble);
//    public double pourcentagePatientsParTrouble(Trouble trouble);



}
