package com.example.tp_poo.models;

public class Anamnese {
    private String nom;

    public Anamnese(String nom) {
        this.nom = nom;
    }
    public String getNom() {
        return nom;
    }

}
