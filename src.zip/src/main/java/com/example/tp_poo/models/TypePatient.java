package com.example.tp_poo.models;

public enum TypePatient {
    ADULTE,ENFANT
}
